(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_bf599dbd._.js",
  "static/chunks/components_SignUp_tsx_eb71d9a1._.js"
],
    source: "dynamic"
});

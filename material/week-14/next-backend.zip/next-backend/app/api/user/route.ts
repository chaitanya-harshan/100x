import { NextRequest, NextResponse } from "next/server";
import { PrismaClient } from "@prisma/client";

const client = new PrismaClient();

export async function POST(req: NextRequest) {
  try {
    const { username, password } = await req.json();
    await client.user.create({
      data: { username, password },
    });
    return NextResponse.json(
      { message: "User created successfully" },
      { status: 201 }
    );

  } catch (err: any) {
    console.error("🚨 Prisma error:", err);
    return NextResponse.json({ error: err.message || "Something went wrong" }, { status: 500 });
  }
}
